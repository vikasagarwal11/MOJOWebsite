# Media Page Photo Disappearance Issue

## Problem Summary
When navigating to the Media page, then navigating away to another page, and returning to the Media page, all photos disappear even though the data is being fetched correctly from Firestore.

## Issue Details

### Symptoms
- User navigates to Media page → Photos display correctly
- User navigates to another page (e.g., Events, Home)
- User navigates back to Media page → **All photos disappear**
- Console logs show data is being fetched (29 items in logs)
- Photos do not render despite data being available

### Root Cause Analysis

#### Primary Issue: State Reset on Component Remount
The `useRealtimeCollection` hook in `src/hooks/useFirestore.ts` initializes state to an empty array `[]` every time the component mounts:

```typescript
const [data, setData] = useState<any[]>([]);
```

**Problem Flow:**
1. Navigate to Media page → Component mounts → State initialized to `[]`
2. Firestore listener receives data → `setData([29 items])` → Photos render
3. Navigate away → Component unmounts → Listener cleanup → State cleared
4. Navigate back → Component remounts → State initialized to `[]` again
5. Component renders with empty array before snapshot arrives
6. Even when snapshot arrives, there may be a race condition preventing re-render

#### Secondary Issues

1. **No Loading State Handling in Media.tsx**
   - Line 64-65: `const { data: mediaFiles } = useRealtimeCollection(...)` doesn't check `loading` state
   - Component renders with empty array during initial load
   - No loading spinner or skeleton UI

2. **Missing Defensive Checks**
   - `Media.tsx` line 100-123 filters `mediaFiles` without ensuring it's an array
   - No null/undefined checks before filtering

3. **Performance Issues**
   - Loading full-size images instead of thumbnails in grid view (MediaCard.tsx line 560-561)
   - No pagination/virtualization in Media.tsx (renders all items at once)
   - MediaGallery.tsx uses InfiniteScroll, but Media.tsx does not

## Console Logs Evidence

```
📸 [MEDIA DEBUG] Raw snapshot: {collectionName: 'media', totalDocs: 29, ...}
📸 [MEDIA DEBUG] After moderation filter: {before: 29, after: 29, filtered: 0, ...}
📸 [MEDIA DEBUG] Final rows: {count: 29, ids: Array(5), allIds: Array(29)}
```

**Key Observation:** Data is being fetched correctly (29 items), but the component renders with an empty array.

## Files Involved

1. **src/pages/Media.tsx** - Main Media page component
   - Uses `useRealtimeCollection` hook
   - Filters and displays media files
   - No loading state handling
   - No pagination (renders all items)

2. **src/hooks/useFirestore.ts** - Firestore hook
   - `useRealtimeCollection` function (lines 328-620)
   - State initialization: `useState<any[]>([])` (line 332)
   - Listener cleanup on unmount (lines 613-616)
   - Debug logging for media collection

3. **src/components/media/MediaCard.tsx** - Media card component
   - Displays individual media items
   - Loads full-size images instead of thumbnails (line 560-561)
   - Uses `loading="lazy"` attribute

4. **src/components/media/MediaGallery.tsx** - Alternative gallery component
   - Uses `InfiniteScroll` for pagination
   - Better performance optimization
   - Not used in main Media.tsx page

5. **src/hooks/useMediaFilters.tsx** - Media filtering hook
   - Client-side filtering logic
   - Used by MediaGallery but not directly by Media.tsx

6. **src/components/media/MediaLightbox.tsx** - Lightbox component
   - Full-screen media viewer
   - Preloading optimization for next/prev items

## Proposed Solutions

### High Priority (Fix the Bug)

1. **Add Loading State Handling**
   ```typescript
   const { data: mediaFiles, loading } = useRealtimeCollection(...);
   if (loading) return <LoadingSpinner />;
   ```

2. **Add Defensive Array Check**
   ```typescript
   const mediaFilesArray = Array.isArray(mediaFiles) ? mediaFiles : [];
   ```

3. **Consider State Preservation**
   - Use React Query or similar for state persistence
   - Or implement a global cache that persists across navigation

### Medium Priority (Performance Improvements)

4. **Use Thumbnails in Grid View**
   - Use `thumbnailUrl` for grid cards
   - Load full-size only in lightbox

5. **Add Pagination to Media.tsx**
   - Use `InfiniteScroll` like MediaGallery.tsx
   - Or use `react-window` for virtualization

6. **Add IntersectionObserver**
   - Use `react-intersection-observer` for better lazy loading
   - Already in dependencies, used in Home.tsx

## Technical Stack
- React 18 with TypeScript
- Firebase Firestore (real-time listeners)
- Vite build tool
- Tailwind CSS

## Environment
- Development environment
- Firebase project: momfitnessmojo
- Storage bucket: mojomediafiles

## Additional Notes
- Service worker caching exists but may not be optimal
- No Redis or containers needed (client-side issue)
- Performance issues are secondary to the main bug

