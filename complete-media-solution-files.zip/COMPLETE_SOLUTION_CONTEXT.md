# Complete Solution Context: Media Page Issues & Thumbnail Optimization

## Overview
This document provides complete context for two related issues:
1. **Media Page Photo Disappearance Bug** - Photos disappear on navigation
2. **Thumbnail Performance Optimization** - Using thumbnails in grid view

---

## Issue 1: Media Page Photo Disappearance

### Problem
When navigating to Media page → away → back, all photos disappear despite data being fetched correctly.

### Root Cause
- `useRealtimeCollection` hook resets state to `[]` on every remount
- `Media.tsx` doesn't check `loading` state, so empty array looks like "no media"
- Component renders with empty array before Firestore snapshot arrives

### Current Implementation Status
✅ **Already Implemented:**
- Thumbnail loading logic with ready flags (MediaCard.tsx lines 115-183)
- `object-contain` CSS to prevent cropping (MediaCard.tsx line 597)
- Fixed aspect-square container (MediaCard.tsx line 627)
- Thumbnail URL state management

❌ **Needs Fix:**
- Loading state handling in Media.tsx
- Image source priority swap (line 561: `originalUrl || thumbnailUrl` → `thumbnailUrl || originalUrl`)
- Memoized query constraints (optional but recommended)

---

## Issue 2: Thumbnail Performance Optimization

### Problem
Currently loading full-size images in grid view, causing:
- High bandwidth usage (80-90% more than needed)
- Slow initial page load
- Poor mobile experience

### Current Implementation Status

✅ **Already Implemented:**
1. **Firebase Extension: `storage-resize-images`**
   - Production: Generates 400x400, 800x800, 1200x1200 thumbnails
   - Dev: Generates 400x400 thumbnails
   - Automatically creates thumbnails on upload
   - Config files: `extensions/storage-resize-images.*.env`

2. **Cloud Function: `onMediaFileFinalize`**
   - Detects thumbnail generation completion
   - Updates Firestore with thumbnail paths and ready flags
   - Handles small/medium/large thumbnail sizes
   - Location: `functions/src/index.ts` lines 1262-1400+

3. **MediaCard.tsx Thumbnail Loading**
   - Checks `thumbnails.smallReady`, `mediumReady`, `largeReady` flags
   - Loads thumbnail URLs with proper fallback chain
   - Priority: medium → small → large → original
   - Handles "thumbnail not ready yet" scenario
   - Location: `src/components/media/MediaCard.tsx` lines 115-183

4. **CSS Rendering**
   - Uses `object-contain` to prevent cropping (line 597)
   - Fixed `aspect-square` container (line 627)
   - Proper overflow handling

❌ **Needs Change:**
- **ONE LINE CHANGE:** Swap image source priority
  - Current: `const imageSrc = originalUrl || thumbnailUrl;` (line 561)
  - Should be: `const imageSrc = thumbnailUrl || originalUrl;`

### Why Thumbnails Don't Crop (Important!)
The comment in MediaCard.tsx (line 557-558) says thumbnails crop faces, but this is **outdated**:
- Current CSS uses `object-contain` which **prevents cropping**
- Square thumbnails work fine with `object-contain`
- The concern was valid when using `object-cover`, but that's not the case

---

## Files Included in This Package

### Core Media Components
1. **src/pages/Media.tsx** - Main Media page (needs loading state fix)
2. **src/components/media/MediaCard.tsx** - Media card component (needs priority swap)
3. **src/components/media/MediaGallery.tsx** - Alternative gallery with InfiniteScroll
4. **src/components/media/MediaLightbox.tsx** - Full-screen viewer

### Hooks & Utilities
5. **src/hooks/useFirestore.ts** - Firestore real-time collection hook (root cause)
6. **src/hooks/useMediaFilters.tsx** - Media filtering logic
7. **src/utils/thumbnailUtils.ts** - Thumbnail URL utilities

### Backend/Infrastructure
8. **functions/src/index.ts** (excerpt) - Cloud Function thumbnail handling
9. **extensions/storage-resize-images.prod.env** - Production thumbnail config
10. **extensions/storage-resize-images.dev.env** - Development thumbnail config

### Documentation
11. **MEDIA_PAGE_ISSUE_DESCRIPTION.md** - Original issue analysis
12. **COMPLETE_SOLUTION_CONTEXT.md** - This file

---

## Required Changes Summary

### Critical (Must Fix)
1. **Media.tsx** - Add loading state check
   ```tsx
   const { data: mediaFiles, loading: mediaLoading } = useRealtimeCollection(...);
   if (mediaLoading) return <LoadingSpinner />;
   ```

2. **MediaCard.tsx line 561** - Swap image source priority
   ```tsx
   // Change from:
   const imageSrc = originalUrl || thumbnailUrl;
   // To:
   const imageSrc = thumbnailUrl || originalUrl;
   ```

### Recommended (High Value)
3. **Media.tsx** - Memoize query constraints
   ```tsx
   const mediaConstraints = useMemo(() => [orderBy('createdAt', 'desc')], []);
   const { data: mediaFiles, loading } = useRealtimeCollection('media', mediaConstraints);
   ```

### Optional (Nice to Have)
4. **MediaCard.tsx** - Responsive thumbnail selection (use medium for grid)
5. **MediaCard.tsx** - Blurred backdrop for premium feel
6. **Media.tsx** - Add pagination/virtualization

---

## Key Implementation Details

### Thumbnail Generation Pipeline
1. User uploads image → Firebase Storage
2. `storage-resize-images` extension triggers → Creates thumbnails
3. Thumbnails saved to: `media/{userId}/{batchId}/thumbnails/{filename}_{size}.ext`
4. `onMediaFileFinalize` Cloud Function detects thumbnail → Updates Firestore
5. Firestore updated with:
   - `thumbnails.smallPath`, `thumbnails.mediumPath`, `thumbnails.largePath`
   - `thumbnails.smallReady`, `thumbnails.mediumReady`, `thumbnails.largeReady`
6. MediaCard.tsx reads ready flags → Loads appropriate thumbnail URL

### Current Thumbnail Loading Logic (MediaCard.tsx lines 115-183)
```typescript
// Priority order:
1. Check mediumReady → Load mediumPath (800x800) - preferred for cards
2. Check smallReady → Load smallPath (400x400) - fallback
3. Check largeReady → Load largePath (1200x1200) - fallback
4. Use original URL if no thumbnails ready
```

### Image Rendering (MediaCard.tsx)
- Container: `aspect-square` (1:1 ratio)
- Image: `object-contain` (prevents cropping, shows full image)
- Background: `bg-[#FFF5F2]` (handles letterboxing)
- Result: Square cards with full images visible (no cropping)

---

## Questions for ChatGPT

1. **Since we already have `object-contain`, is the blurred backdrop still beneficial?**
   - Current implementation already prevents cropping
   - Backdrop is optional visual polish, correct?

2. **For responsive thumbnail selection, should we:**
   - Modify existing thumbnail loading logic (lines 122-164)?
   - Or create a separate function?
   - Or just use medium (800x800) for all grid views?

3. **For srcSet implementation:**
   - Worth loading all 3 thumbnail URLs simultaneously?
   - Or is medium (800x800) sufficient for all grid views?

4. **In-memory cache in useRealtimeCollection:**
   - Module-level Map to persist last snapshot?
   - Any concerns about stale data?
   - Should we add TTL or version checks?

---

## Testing Checklist

After implementing fixes:
- [ ] Navigate to Media page → away → back (photos should persist)
- [ ] Check network tab (should load thumbnails, not originals)
- [ ] Verify images don't crop faces (object-contain working)
- [ ] Test on mobile (should load 400x400 thumbnails)
- [ ] Test on desktop (should load 800x800 or 1200x1200)
- [ ] Verify loading spinner shows during initial load
- [ ] Test with slow network (should see loading state)

---

## Performance Impact

### Before (Current)
- Grid view: Full-size images (~2-5MB each)
- Initial load: 29 images × 3MB = ~87MB
- Load time: 10-30 seconds on 4G

### After (With Thumbnails)
- Grid view: Thumbnails (~50-200KB each)
- Initial load: 29 images × 100KB = ~2.9MB
- Load time: 1-3 seconds on 4G
- **Bandwidth reduction: ~95%**

---

## Notes
- No changes needed to thumbnail generation pipeline
- No changes needed to CSS (object-contain already correct)
- Only code changes: loading state + image source priority
- All infrastructure already in place

