import { Timestamp } from 'firebase/firestore';

/**
 * Comprehensive data sanitization utility to prevent Firebase Timestamp errors
 * This ensures all data is properly converted before being passed to functions that expect strings
 */

export function sanitizeFirebaseData(data: any): any {
  if (data === null || data === undefined) {
    return data;
  }

  if (Array.isArray(data)) {
    return data.map(item => sanitizeFirebaseData(item));
  }

  if (typeof data === 'object') {
    const sanitized: any = {};
    
    for (const [key, value] of Object.entries(data)) {
      // Handle Firebase Timestamps
      if (isFirebaseTimestamp(value)) {
        sanitized[key] = convertTimestampToDate(value);
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = sanitizeFirebaseData(value);
      } else {
        sanitized[key] = value;
      }
    }
    
    return sanitized;
  }

  return data;
}

export function isFirebaseTimestamp(value: any): boolean {
  if (!value || typeof value !== 'object') {
    return false;
  }

  // Check for Firebase Timestamp properties
  return (
    (value.seconds !== undefined && typeof value.seconds === 'number') ||
    (value.toDate && typeof value.toDate === 'function') ||
    (value.toMillis && typeof value.toMillis === 'function') ||
    (value._seconds !== undefined && typeof value._seconds === 'number') ||
    (value._nanoseconds !== undefined && typeof value._nanoseconds === 'number')
  );
}

export function convertTimestampToDate(timestamp: any): Date {
  if (!timestamp) {
    return new Date();
  }

  try {
    // Handle Firebase Timestamp with toDate method
    if (timestamp.toDate && typeof timestamp.toDate === 'function') {
      return timestamp.toDate();
    }
    
    // Handle Firebase Timestamp with toMillis method
    if (timestamp.toMillis && typeof timestamp.toMillis === 'function') {
      return new Date(timestamp.toMillis());
    }
    
    // Handle Firebase Timestamp with seconds property
    if (timestamp.seconds !== undefined && typeof timestamp.seconds === 'number') {
      return new Date(timestamp.seconds * 1000 + (timestamp.nanoseconds || 0) / 1000000);
    }
    
    // Handle Firebase Timestamp with _seconds property (internal format)
    if (timestamp._seconds !== undefined && typeof timestamp._seconds === 'number') {
      return new Date(timestamp._seconds * 1000 + (timestamp._nanoseconds || 0) / 1000000);
    }
    
    // Handle JavaScript Date
    if (timestamp instanceof Date) {
      return timestamp;
    }
    
    // Handle timestamp number (milliseconds)
    if (typeof timestamp === 'number') {
      return new Date(timestamp);
    }
    
    // Handle timestamp string
    if (typeof timestamp === 'string') {
      const date = new Date(timestamp);
      if (isNaN(date.getTime())) {
        console.warn('Invalid timestamp string:', timestamp);
        return new Date();
      }
      return date;
    }
    
    console.warn('Unknown timestamp format:', timestamp);
    return new Date();
  } catch (error) {
    console.error('Error converting timestamp to date:', timestamp, error);
    return new Date();
  }
}

export function safeStringConversion(value: any): string {
  if (value === null || value === undefined) {
    return '';
  }

  if (typeof value === 'string') {
    return value;
  }

  if (typeof value === 'number') {
    return value.toString();
  }

  if (typeof value === 'boolean') {
    return value.toString();
  }

  if (isFirebaseTimestamp(value)) {
    return convertTimestampToDate(value).toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (typeof value === 'object') {
    try {
      return JSON.stringify(value);
    } catch (error) {
      console.warn('Could not stringify object:', value);
      return '[Object]';
    }
  }

  return String(value);
}

export function safeArrayConversion(value: any): any[] {
  if (Array.isArray(value)) {
    return value.map(item => sanitizeFirebaseData(item));
  }

  if (value === null || value === undefined) {
    return [];
  }

  return [sanitizeFirebaseData(value)];
}

export function safeObjectConversion(value: any): Record<string, any> {
  if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
    return sanitizeFirebaseData(value);
  }

  if (value === null || value === undefined) {
    return {};
  }

  return { value: sanitizeFirebaseData(value) };
}
