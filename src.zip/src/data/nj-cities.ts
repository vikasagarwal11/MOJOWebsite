// Replace/extend this array with the full NJ places list.
// Source you referenced: “Listing of all Zip Codes in the state of New Jersey”. :contentReference[oaicite:1]{index=1}
export const NJ_CITIES: string[] = [
  'Short Hills',
  'Summit',
  'Westfield',
  'Newark',
  'Jersey City',
  'Hoboken',
  'Princeton',
  'Edison',
  'Trenton',
  'Montclair',
  'Morristown',
  'Paramus',
  'Bridgewater',
  'Clifton',
  'Elizabeth',
];
