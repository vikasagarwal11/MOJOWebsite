// src/hooks/useFirestore.ts
import { useState, useEffect } from 'react';
import {
  collection,
  doc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  type QueryConstraint,
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

/** Remove undefined so Firestore doesn’t throw on writes. */
function stripUndefined<T extends Record<string, any>>(obj: T): Partial<T> {
  return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined)) as Partial<T>;
}

/** Convert common timestamp fields (if present) to Date for UI convenience. */
function normalizeDoc(docData: any) {
  const out = { id: docData.id, ...docData };
  const tsFields = ['createdAt', 'updatedAt', 'date', 'validUntil', 'startAt'];
  for (const f of tsFields) {
    const v = (out as any)[f];
    (out as any)[f] = v?.toDate?.() ? v.toDate() : v instanceof Date ? v : v;
  }
  return out;
}

/* ---------- helpers to inspect/augment constraints (best-effort) ---------- */
function hasWhereEquals(constraints: QueryConstraint[], field: string, value: any) {
  return constraints.some((c: any) => {
    if (c?.type !== 'where') return false;
    const f =
      c?.field?.toString?.() ??
      c?._field?.toString?.() ??
      c?._field?.segments?.[0] ??
      c?._field?.canonicalString?.();
    return f === field && (c?.opStr === '==' || c?._op === '==') && (c?.value === value || c?._value === value);
  });
}

function hasAnyOrderBy(constraints: QueryConstraint[]) {
  return constraints.some((c: any) => c?.type === 'orderBy');
}

function hasOrderByField(constraints: QueryConstraint[], field: string) {
  return constraints.some((c: any) => {
    if (c?.type !== 'orderBy') return false;
    const f =
      c?.field?.toString?.() ??
      c?._field?.toString?.() ??
      c?._field?.segments?.[0] ??
      c?._field?.canonicalString?.();
    return f === field;
  });
}

/**
 * Enforce guest-readable queries:
 * - posts  : where(isPublic == true), default orderBy(createdAt desc)
 * - events : where(public == true),   default orderBy(startAt  asc)
 * - media  : where(isPublic == true), default orderBy(createdAt desc)
 */
function enforceGuestPolicy(
  collectionName: string,
  isAuthed: boolean,
  userConstraints: QueryConstraint[]
): QueryConstraint[] {
  if (isAuthed) return userConstraints;

  const out = [...userConstraints];

  if (collectionName === 'posts') {
    if (!hasWhereEquals(out, 'isPublic', true)) out.unshift(where('isPublic', '==', true));
    if (!hasAnyOrderBy(out) && !hasOrderByField(out, 'createdAt')) {
      out.push(orderBy('createdAt', 'desc'));
    }
  } else if (collectionName === 'events') {
    // For events, we need to be more flexible with field types
    // Check if user has provided specific constraints
    const hasPublicField = hasWhereEquals(out, 'public', true);
    const hasVisibilityField = hasWhereEquals(out, 'visibility', 'public');
    
    if (!hasPublicField && !hasVisibilityField) {
      // For guests, only show public events
      // Try visibility field first (newer events), then fallback to public field (legacy)
      // Note: Firestore doesn't support OR queries easily, so we'll use visibility as primary
      out.unshift(where('visibility', '==', 'public'));
    }
    
    // Add default ordering if none provided
    if (!hasAnyOrderBy(out) && !hasOrderByField(out, 'startAt')) {
      out.push(orderBy('startAt', 'asc'));
    }
  } else if (collectionName === 'media') {
    if (!hasWhereEquals(out, 'isPublic', true)) out.unshift(where('isPublic', '==', true));
    if (!hasAnyOrderBy(out) && !hasOrderByField(out, 'createdAt')) {
      out.push(orderBy('createdAt', 'desc'));
    }
  }

  return out;
}

export const useFirestore = () => {
  const { currentUser } = useAuth();

  const getCollection = async (collectionName: string) => {
    try {
      const snap = await getDocs(collection(db, collectionName));
      return snap.docs.map(d => normalizeDoc({ id: d.id, ...d.data() }));
    } catch (error) {
      console.error(`Error getting ${collectionName}:`, error);
      toast.error(`Failed to load ${collectionName}`);
      return [];
    }
  };

  const addDocument = async (collectionName: string, data: any) => {
    try {
      const cleaned = stripUndefined({
        ...data,
        createdAt: data?.createdAt ?? serverTimestamp(),
        updatedAt: data?.updatedAt ?? serverTimestamp(),
      });
      const ref = await addDoc(collection(db, collectionName), cleaned);
      toast.success('Document created successfully');
      return ref.id;
    } catch (error) {
      console.error(`Error adding to ${collectionName}:`, error);
      toast.error('Failed to create document');
      throw error;
    }
  };

  const updateDocument = async (collectionName: string, docId: string, data: any) => {
    try {
      const cleaned = stripUndefined({ ...data, updatedAt: serverTimestamp() });
      await updateDoc(doc(db, collectionName, docId), cleaned);
      toast.success('Document updated successfully');
    } catch (error) {
      console.error(`Error updating ${collectionName}:`, error);
      toast.error('Failed to update document');
      throw error;
    }
  };

  const deleteDocument = async (collectionName: string, docId: string) => {
    try {
      await deleteDoc(doc(db, collectionName, docId));
      toast.success('Document deleted successfully');
    } catch (error) {
      console.error(`Error deleting from ${collectionName}:`, error);
      toast.error('Failed to delete document');
      throw error;
    }
  };

  const useRealtimeCollection = (
    collectionName: string,
    queryConstraints: QueryConstraint[] = []
  ) => {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      const authed = !!currentUser;
      let safeConstraints = enforceGuestPolicy(collectionName, authed, queryConstraints);
      
      // Special handling for events collection to ensure proper constraints
      if (collectionName === 'events' && authed) {
        // Always enforce visibility constraints for authenticated users
        const hasVisibilityConstraint = queryConstraints.some(c => 
          c.type === 'where' && 
          (c.fieldPath === 'visibility' || c.fieldPath === 'public')
        );
        const hasCreatorConstraint = queryConstraints.some(c => 
          c.type === 'where' && c.fieldPath === 'createdBy'
        );
        const hasInvitedConstraint = queryConstraints.some(c => 
          c.type === 'where' && c.fieldPath === 'invitedUsers'
        );
        
        // If no proper constraints, add default ones based on user role
        if (!hasVisibilityConstraint && !hasCreatorConstraint && !hasInvitedConstraint) {
          if (currentUser?.role === 'admin') {
            // Admin can see all events - no additional constraints needed
          } else if (currentUser?.role === 'member') {
            // Members can see public, members-only, and their own events
            safeConstraints = [
              ...safeConstraints,
              where('visibility', 'in', ['public', 'members']),
              where('createdBy', '==', currentUser.id)
            ];
          } else {
            // Regular authenticated users can only see public events and their own
            safeConstraints = [
              ...safeConstraints,
              where('visibility', '==', 'public'),
              where('createdAt', '<=', new Date()) // Past events
            ];
          }
        }
      }
      
      // Debug logging for events collection
      if (collectionName === 'events') {
        console.log('🔍 Events query constraints:', {
          isAuthed: authed,
          originalConstraints: queryConstraints,
          safeConstraints: safeConstraints,
          userRole: currentUser?.role,
          enforcedConstraints: collectionName === 'events' && authed
        });
      }

      const q =
        safeConstraints.length > 0
          ? query(collection(db, collectionName), ...safeConstraints)
          : query(collection(db, collectionName));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const rows = snapshot.docs.map(d => normalizeDoc({ id: d.id, ...d.data() }));
          setData(rows);
          setLoading(false);
        },
        (error: any) => {
          console.error(`Error listening to ${collectionName}:`, error);
          setLoading(false);

          if (error?.code === 'failed-precondition') {
            toast.error('This query needs a Firestore composite index. Use the console link in devtools to create it.');
          } else if (error?.code === 'permission-denied') {
            if (!authed) {
              toast.error('Sign in to view private items (or filter to public content).');
            } else {
              toast.error('You do not have permission to read these documents.');
            }
          } else {
            toast.error('Failed to load data.');
          }
        }
      );

      return () => unsubscribe();
    }, [collectionName, currentUser?.id, currentUser?.role, JSON.stringify(queryConstraints)]);

    return { data, loading };
  };

  return {
    getCollection,
    addDocument,
    updateDocument,
    deleteDocument,
    useRealtimeCollection,
  };
};
